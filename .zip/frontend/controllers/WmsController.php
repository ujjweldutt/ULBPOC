<?php

namespace frontend\controllers;

use Yii;
use frontend\models\Wms;
use frontend\models\WmsSearch;
use frontend\models\WmsWorkItems;
use frontend\models\MstRateType;
use frontend\models\MstAnnouncement;

use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;

/**
 * WmsController implements the CRUD actions for Wms model.
 */
class WmsController extends Controller
{
    /**
     * {@inheritdoc}
     */
    public function behaviors()
    {
        return [
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'delete' => ['POST'],
                ],
            ],
        ];
    }

    /**
     * Lists all Wms models.
     * @return mixed
     */
    public function actionIndex()
    {
        $searchModel = new WmsSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
        ]);
    }

    /**
     * Displays a single Wms model.
     * @param integer $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionView($id)
    {
        return $this->render('view', [
            'model' => $this->findModel($id),
        ]);
    }

    /**
     * Creates a new Wms model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */
    public function actionCreate()
    {
        $model = new Wms();
        $bytes = random_bytes(20);
        $alphanumeric = bin2hex($bytes);
        $model->work_code_number = $alphanumeric;

        
        $ward = Yii::$app->request->post('Wms'); 
        if(!empty($ward)){
            $wardText = implode(",", $ward['ward']);
            $model->ward = $wardText;
        }
        
        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            
            return $this->redirect(['wms-work-items/create', 'id' => $model->id]);
        }
        //echo "<pre>"; print_r($model->errors); die;
        

        return $this->render('create', [
            'model' => $model,
        ]);
    }

    /**
     * Updates an existing Wms model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param integer $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionUpdate($id)
    {
        $model = $this->findModel($id);

        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            return $this->redirect(['view', 'id' => $model->id]);
        }

        return $this->render('update', [
            'model' => $model,
        ]);   
    }

    /**
     * Deletes an existing Wms model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param integer $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionDelete($id)
    {
        $this->findModel($id)->delete();

        return $this->redirect(['index']);
    }

    /**
     * Finds the Wms model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param integer $id
     * @return Wms the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id)
    {
        if (($model = Wms::findOne($id)) !== null) {
            return $model;
        }

        throw new NotFoundHttpException('The requested page does not exist.');
    }

    
    public function actionEstimate()
    {
        $dataProvider = Wms::find()->all();
        return $this->render('estimate_list', [
            'dataProvider' => $dataProvider,
        ]);
    }

    public function actionEstimateDetails($id)
    {
        $dataProvider = Wms::find()->where(["id"=>$id])->one();
        $dataWmsWork = WmsWorkItems::find()->where(["wms_id"=>$id])->all();
        $ratetypedata = MstRateType::find()->where(["is_active"=>'Y'])->all();
        $flag=0;
        if(isset($_POST['save']))
        {
           
                foreach(Yii::$app->request->post('workitemid') as $workitemid){
                    $dataWmsWork = WmsWorkItems::find()->where(["id"=>$workitemid])->one();
                    $dataWmsWork->total_amount=$_POST['totalrate'][$workitemid];
                    $dataWmsWork->save();
                    $flag=1;
                }

                if($flag>0){
                    Yii::$app->session->setFlash("success","Total Amount Updated Successfully.");
                  
                }


        }
      
        return $this->render('estimate', [
            'model' => $dataProvider,
            'dataWmsWork' => $dataWmsWork,
            'ratetypedata' => $ratetypedata,
        ]);
    }


    public function actionGetItems(){
        $item_type_id=$_GET['item_type_id'];
        $query = (new \yii\db\Query())
        ->select(['s.name','s.id'])->from(['s' => 'mst_items_groups'])
        ->where([
        's.item_id'=>$item_type_id]);
        $command = $query->createCommand();
        $data = $command->queryAll();
        $table="";
        $table.='<table class="table table-bordered" >';
        $table.='<thead>';
        $table.='<tr >
                    <th>S.No</th> 
                    <th>Name</th> 
                </tr>
            </thead>';
        if(isset($data)): $i=1; foreach ($data as $key => $val):
        $table.='<tbody>';
        $table.='<td>' .$i.'</td> ';
        $table.='<td> <a onclick="getitemlist('.$val['id'].')" class="itemgrouplink cursor-pointer"  >'.$val['name'].'</a></td> ';
        $table.='</tbody>';
        $i++; endforeach; endif; 
        $table.='</table>'; 
        
        return $table;
    }
 
    
    public function actionGetItemslist(){
        $itemid=$_GET['itemid'];
        $query = (new \yii\db\Query())
        ->select(['s.name','s.discription','s.unit','s.id'])->from(['s' => 'mst_items_type'])
        ->where([
        's.item_group_id'=>$itemid]);
        $command = $query->createCommand();
        $data = $command->queryAll();
        $table="";
        $table.='<table class="table table-bordered" >';
        $table.='<thead>';
        $table.='<tr >
                    <th>S.No</th> 
                    <th>Name</th> 
                </tr>
            </thead>';
        if(isset($data)): $i=1; foreach ($data as $key => $v):
        $table.='<tbody>';
        $table.='<td>' .$i.'</td> ';
        $table.='<td> <a onclick="getitem('.$v['id'].')" class="getitem cursor-pointer" data-unit='.$v['unit'].'  data-des='.$v['discription'].' data-item='.$v['name'].' >'.$v['name'].'</a></td> ';
        $table.='</tbody>';
        $i++; endforeach; endif; 
        $table.='</table>'; 
        
        return $table;
    }

    function actionAddItems(){

    }

    function actionDeductItems(){
        
    }

    


}
